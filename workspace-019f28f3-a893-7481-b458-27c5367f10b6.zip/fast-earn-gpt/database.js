const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');

const db = new Database(path.join(__dirname, 'data.db'));

// Enable WAL mode for better performance
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    userId TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    whatsappNumber TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    withdrawalPin TEXT NOT NULL,
    referredBy TEXT,
    walletBalance REAL DEFAULT 0,
    totalEarnedLifetime REAL DEFAULT 0,
    lastCheckInDate TEXT,
    lastLoginIp TEXT,
    isBanned INTEGER DEFAULT 0,
    createdAt TEXT DEFAULT (datetime('now', 'localtime'))
  );

  CREATE TABLE IF NOT EXISTS transactions (
    transactionId TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('Earning', 'Commission', 'Withdrawal')),
    description TEXT,
    amount REAL NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('Pending', 'Success', 'Failed')),
    createdAt TEXT DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (userId) REFERENCES users(userId)
  );

  CREATE TABLE IF NOT EXISTS general_activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId TEXT NOT NULL,
    action TEXT NOT NULL,
    deviceIp TEXT,
    createdAt TEXT DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (userId) REFERENCES users(userId)
  );

  CREATE TABLE IF NOT EXISTS referral_activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sponsorId TEXT NOT NULL,
    referralName TEXT NOT NULL,
    actionType TEXT NOT NULL,
    commissionEarned REAL DEFAULT 0,
    createdAt TEXT DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (sponsorId) REFERENCES users(userId)
  );

  CREATE TABLE IF NOT EXISTS withdrawal_logs (
    logId TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    bankName TEXT NOT NULL,
    accountNumber TEXT NOT NULL,
    accountName TEXT NOT NULL,
    amount REAL NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('Pending', 'Success', 'Failed')),
    createdAt TEXT DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (userId) REFERENCES users(userId)
  );

  CREATE TABLE IF NOT EXISTS global_config (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    createdAt TEXT DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (userId) REFERENCES users(userId)
  );

  CREATE TABLE IF NOT EXISTS admin_sessions (
    token TEXT PRIMARY KEY,
    createdAt TEXT DEFAULT (datetime('now', 'localtime'))
  );
`);

// Initialize global config defaults
const initConfig = db.prepare('INSERT OR IGNORE INTO global_config (key, value) VALUES (?, ?)');
initConfig.run('isMaintenanceMode', 'false');
initConfig.run('isWithdrawalActive', 'true');
initConfig.run('usdToNairaRate', '1600');
initConfig.run('adminToken', 'FastAdmin2024!Secure#Token');

// Create admin user if not exists
const adminExists = db.prepare('SELECT userId FROM users WHERE userId = ?').get('admin_master');
if (!adminExists) {
  const hash = bcrypt.hashSync('Admin@FastEarn2024', 10);
  db.prepare(`INSERT INTO users (userId, name, whatsappNumber, password, withdrawalPin, walletBalance, totalEarnedLifetime, isBanned)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run('admin_master', 'System Admin', '0000000000', hash, '0000', 0, 0, 0);
}

module.exports = db;
