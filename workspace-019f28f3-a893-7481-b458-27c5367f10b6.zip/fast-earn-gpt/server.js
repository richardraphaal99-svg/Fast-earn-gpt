const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const cookieParser = require('cookie-parser');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Rate limiting
const rateLimitMap = new Map();
const rateLimit = (req, res, next) => {
  const ip = req.ip || req.connection.remoteAddress;
  const now = Date.now();
  const windowMs = 60000; // 1 minute
  const maxRequests = 30;

  if (!rateLimitMap.has(ip)) rateLimitMap.set(ip, []);
  const requests = rateLimitMap.get(ip).filter(t => now - t < windowMs);
  requests.push(now);
  rateLimitMap.set(ip, requests);

  res.set('X-RateLimit-Limit', maxRequests);
  res.set('X-RateLimit-Remaining', Math.max(0, maxRequests - requests.length));

  if (requests.length > maxRequests) {
    return res.status(429).json({ error: 'Too many requests. Please slow down.' });
  }
  next();
};

app.use(rateLimit);

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Helper functions
function generateId() {
  return crypto.randomUUID();
}

function getClientIp(req) {
  return req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.connection.remoteAddress || req.ip;
}

function getSession(req) {
  const token = req.headers.authorization?.replace('Bearer ', '') || req.cookies.session;
  if (!token) return null;
  const session = db.prepare('SELECT * FROM sessions WHERE token = ?').get(token);
  if (!session) return null;
  const user = db.prepare('SELECT * FROM users WHERE userId = ?').get(session.userId);
  return user;
}

function requireAuth(req, res, next) {
  const user = getSession(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });
  if (user.isBanned) return res.status(403).json({ error: 'Account banned' });
  req.user = user;
  next();
}

function getAdminSession(req) {
  const token = req.headers.authorization?.replace('Bearer ', '') || req.cookies.admin_session;
  if (!token) return null;
  return db.prepare('SELECT * FROM admin_sessions WHERE token = ?').get(token);
}

function requireAdmin(req, res, next) {
  const session = getAdminSession(req);
  if (!session) return res.status(401).json({ error: 'Admin access required' });
  next();
}

function getConfig() {
  const rows = db.prepare('SELECT * FROM global_config').all();
  const config = {};
  rows.forEach(r => {
    if (r.value === 'true') config[r.key] = true;
    else if (r.value === 'false') config[r.key] = false;
    else if (!isNaN(r.value)) config[r.key] = parseFloat(r.value);
    else config[r.key] = r.value;
  });
  return config;
}

function sanitizeName(name) {
  const parts = name.split(' ');
  if (parts.length > 1) {
    return parts[0] + ' ' + parts[1][0] + '.';
  }
  return name;
}

// ============ PUBLIC ROUTES ============

// Check maintenance mode
app.get('/api/status', (req, res) => {
  const config = getConfig();
  res.json({ maintenanceMode: config.isMaintenanceMode });
});

// Register
app.post('/api/register', (req, res) => {
  const config = getConfig();
  if (config.isMaintenanceMode) return res.status(503).json({ error: 'System is under maintenance' });

  const { name, whatsappNumber, password, withdrawalPin, referralCode } = req.body;
  if (!name || !whatsappNumber || !password || !withdrawalPin) {
    return res.status(400).json({ error: 'All fields are required' });
  }
  if (withdrawalPin.length !== 4 || isNaN(withdrawalPin)) {
    return res.status(400).json({ error: 'Withdrawal PIN must be exactly 4 digits' });
  }

  const ip = getClientIp(req);

  // Check max 5 accounts per IP
  const ipCount = db.prepare('SELECT COUNT(*) as count FROM users WHERE lastLoginIp = ?').get(ip);
  if (ipCount.count >= 5) {
    return res.status(403).json({ error: 'Maximum 5 accounts per network. Contact support.' });
  }

  // Check if WhatsApp number already exists
  const existing = db.prepare('SELECT userId FROM users WHERE whatsappNumber = ?').get(whatsappNumber);
  if (existing) {
    return res.status(400).json({ error: 'WhatsApp number already registered' });
  }

  const userId = generateId();
  const hashedPassword = bcrypt.hashSync(password, 10);
  const hashedPin = bcrypt.hashSync(withdrawalPin, 10);

  // Validate referral code
  let sponsor = null;
  let fraudFlagged = false;
  if (referralCode) {
    sponsor = db.prepare('SELECT * FROM users WHERE userId = ?').get(referralCode);
    if (!sponsor) {
      return res.status(400).json({ error: 'Invalid referral code' });
    }
    // Fraud check: same IP as sponsor
    if (sponsor.lastLoginIp === ip) {
      fraudFlagged = true;
    }
  }

  db.prepare(`INSERT INTO users (userId, name, whatsappNumber, password, withdrawalPin, referredBy, lastLoginIp)
    VALUES (?, ?, ?, ?, ?, ?, ?)`).run(userId, name, whatsappNumber, hashedPassword, hashedPin, referralCode || null, ip);

  // Log activity
  db.prepare('INSERT INTO general_activity (userId, action, deviceIp) VALUES (?, ?, ?)').run(userId, 'Account registered', ip);

  // If referred and not fraud-flagged, log referral activity
  if (sponsor && !fraudFlagged) {
    db.prepare('INSERT INTO referral_activity (sponsorId, referralName, actionType, commissionEarned) VALUES (?, ?, ?, ?)')
      .run(sponsor.userId, name.split(' ')[0], 'Referral Signup', 0);
  }
  if (sponsor && fraudFlagged) {
    db.prepare('INSERT INTO referral_activity (sponsorId, referralName, actionType, commissionEarned) VALUES (?, ?, ?, ?)')
      .run(sponsor.userId, name.split(' ')[0], 'Referral Signup (IP Flagged)', 0);
  }

  // Create session
  const token = generateId();
  db.prepare('INSERT INTO sessions (token, userId) VALUES (?, ?)').run(token, userId);

  res.json({ success: true, token, user: { userId, name, whatsappNumber, walletBalance: 0, referralCode: userId } });
});

// Login
app.post('/api/login', (req, res) => {
  const config = getConfig();
  if (config.isMaintenanceMode) return res.status(503).json({ error: 'System is under maintenance' });

  const { whatsappNumber, password } = req.body;
  if (!whatsappNumber || !password) {
    return res.status(400).json({ error: 'WhatsApp number and password required' });
  }

  const user = db.prepare('SELECT * FROM users WHERE whatsappNumber = ?').get(whatsappNumber);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  if (user.isBanned) return res.status(403).json({ error: 'Account has been banned' });

  if (!bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  // Update IP
  const ip = getClientIp(req);
  db.prepare('UPDATE users SET lastLoginIp = ? WHERE userId = ?').run(ip, user.userId);

  // Log activity
  db.prepare('INSERT INTO general_activity (userId, action, deviceIp) VALUES (?, ?, ?)').run(user.userId, 'Logged in', ip);

  // Create session
  const token = generateId();
  db.prepare('INSERT INTO sessions (token, userId) VALUES (?, ?)').run(token, user.userId);

  res.json({
    success: true,
    token,
    user: {
      userId: user.userId,
      name: user.name,
      whatsappNumber: user.whatsappNumber,
      walletBalance: user.walletBalance,
      totalEarnedLifetime: user.totalEarnedLifetime,
      referralCode: user.userId
    }
  });
});

// ============ AUTHENTICATED USER ROUTES ============

app.get('/api/dashboard', requireAuth, (req, res) => {
  const user = req.user;
  const config = getConfig();
  const canCheckIn = !user.lastCheckInDate || user.lastCheckInDate !== new Date().toLocaleDateString('en-CA', { timeZone: 'Africa/Lagos' });

  res.json({
    user: {
      userId: user.userId,
      name: user.name,
      whatsappNumber: user.whatsappNumber,
      walletBalance: user.walletBalance,
      totalEarnedLifetime: user.totalEarnedLifetime,
      referralCode: user.userId
    },
    canCheckIn,
    withdrawalActive: config.isWithdrawalActive
  });
});

// Daily Check-In
app.post('/api/checkin', requireAuth, (req, res) => {
  const user = req.user;
  const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Africa/Lagos' });

  if (user.lastCheckInDate === today) {
    return res.status(400).json({ error: 'Already checked in today. Come back at midnight!' });
  }

  const reward = 10;
  let commissionAmount = 0;

  // Credit user
  db.prepare('UPDATE users SET walletBalance = walletBalance + ?, totalEarnedLifetime = totalEarnedLifetime + ?, lastCheckInDate = ? WHERE userId = ?')
    .run(reward, reward, today, user.userId);

  // Create transaction
  const txId = generateId();
  db.prepare('INSERT INTO transactions (transactionId, userId, type, description, amount, status) VALUES (?, ?, ?, ?, ?, ?)')
    .run(txId, user.userId, 'Earning', 'Daily Check-In Reward', reward, 'Success');

  // Log activity
  db.prepare('INSERT INTO general_activity (userId, action, deviceIp) VALUES (?, ?, ?)')
    .run(user.userId, 'Daily Check-In', getClientIp(req));

  // Referral commission
  if (user.referredBy) {
    const sponsor = db.prepare('SELECT * FROM users WHERE userId = ?').get(user.referredBy);
    if (sponsor && !sponsor.isBanned) {
      commissionAmount = reward * 0.2; // 20% = ₦2
      db.prepare('UPDATE users SET walletBalance = walletBalance + ?, totalEarnedLifetime = totalEarnedLifetime + ? WHERE userId = ?')
        .run(commissionAmount, commissionAmount, sponsor.userId);

      const commTxId = generateId();
      db.prepare('INSERT INTO transactions (transactionId, userId, type, description, amount, status) VALUES (?, ?, ?, ?, ?, ?)')
        .run(commTxId, sponsor.userId, 'Commission', `Referral commission from ${user.name.split(' ')[0]}'s check-in`, commissionAmount, 'Success');

      db.prepare('INSERT INTO referral_activity (sponsorId, referralName, actionType, commissionEarned) VALUES (?, ?, ?, ?)')
        .run(sponsor.userId, user.name.split(' ')[0], 'Daily Check-In Commission', commissionAmount);
    }
  }

  const newUser = db.prepare('SELECT walletBalance, totalEarnedLifetime FROM users WHERE userId = ?').get(user.userId);
  res.json({ success: true, reward, commission: commissionAmount, newBalance: newUser.walletBalance });
});

// Leaderboard
app.get('/api/leaderboard', requireAuth, (req, res) => {
  const top10 = db.prepare('SELECT name, totalEarnedLifetime FROM users WHERE userId != ? AND isBanned = 0 ORDER BY totalEarnedLifetime DESC LIMIT 10')
    .all('admin_master');

  const leaderboard = top10.map((u, i) => ({
    rank: i + 1,
    name: sanitizeName(u.name),
    earnings: u.totalEarnedLifetime
  }));

  res.json(leaderboard);
});

// Network Activity Stream
app.get('/api/activity', requireAuth, (req, res) => {
  const user = req.user;

  // Transaction history
  const transactions = db.prepare('SELECT * FROM transactions WHERE userId = ? ORDER BY createdAt DESC LIMIT 50').all(user.userId);

  // General activity
  const activities = db.prepare('SELECT * FROM general_activity WHERE userId = ? ORDER BY createdAt DESC LIMIT 50').all(user.userId);

  // Referral activity (sponsor's referrals)
  const referrals = db.prepare('SELECT * FROM referral_activity WHERE sponsorId = ? ORDER BY createdAt DESC LIMIT 50').all(user.userId);

  res.json({ transactions, activities, referrals });
});

// Withdrawal Request
app.post('/api/withdraw', requireAuth, (req, res) => {
  const config = getConfig();
  if (!config.isWithdrawalActive) {
    return res.status(400).json({ error: 'Withdrawals are currently disabled' });
  }

  const { bankName, accountNumber, accountName, amount, pin } = req.body;
  const user = req.user;

  if (!bankName || !accountNumber || !accountName || !amount || !pin) {
    return res.status(400).json({ error: 'All fields are required' });
  }
  if (amount < 1000) return res.status(400).json({ error: 'Minimum withdrawal is ₦1,000' });
  if (amount > 100000) return res.status(400).json({ error: 'Maximum withdrawal is ₦100,000' });
  if (amount > user.walletBalance) return res.status(400).json({ error: 'Insufficient balance' });

  // Verify PIN
  if (!bcrypt.compareSync(pin, user.withdrawalPin)) {
    return res.status(400).json({ error: 'Invalid withdrawal PIN' });
  }

  const logId = generateId();
  const txId = generateId();

  // Deduct balance
  db.prepare('UPDATE users SET walletBalance = walletBalance - ? WHERE userId = ?').run(amount, user.userId);

  // Create withdrawal log
  db.prepare('INSERT INTO withdrawal_logs (logId, userId, bankName, accountNumber, accountName, amount, status) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(logId, user.userId, bankName, accountNumber, accountName, amount, 'Pending');

  // Create transaction
  db.prepare('INSERT INTO transactions (transactionId, userId, type, description, amount, status) VALUES (?, ?, ?, ?, ?, ?)')
    .run(txId, user.userId, 'Withdrawal', `Withdrawal to ${bankName} - ${accountNumber}`, amount, 'Pending');

  // Log activity
  db.prepare('INSERT INTO general_activity (userId, action, deviceIp) VALUES (?, ?, ?)')
    .run(user.userId, `Withdrawal request: ₦${amount}`, getClientIp(req));

  res.json({
    success: true,
    message: 'Please wait for admin to confirm. Allow 24-48 hours for your account to be verified and your payment processed.'
  });
});

// Withdrawal history
app.get('/api/withdrawals', requireAuth, (req, res) => {
  const withdrawals = db.prepare('SELECT * FROM withdrawal_logs WHERE userId = ? ORDER BY createdAt DESC').all(req.user.userId);
  res.json(withdrawals);
});

// ============ CPALead POSTBACK ============
app.get('/api/postback/cpalead', (req, res) => {
  const { subid, payout, title } = req.query;
  if (!subid || !payout) return res.status(400).send('0');

  const user = db.prepare('SELECT * FROM users WHERE userId = ?').get(subid);
  if (!user || user.isBanned) return res.send('1'); // Still return 1 to acknowledge

  const config = getConfig();
  const rate = config.usdToNairaRate || 1600;
  const payoutUSD = parseFloat(payout);
  const totalNaira = payoutUSD * rate;
  const userShare = totalNaira * 0.5; // 50% to user
  const platformShare = totalNaira * 0.5; // 50% to platform

  // Credit user
  db.prepare('UPDATE users SET walletBalance = walletBalance + ?, totalEarnedLifetime = totalEarnedLifetime + ? WHERE userId = ?')
    .run(userShare, userShare, user.userId);

  // Transaction log
  const txId = generateId();
  db.prepare('INSERT INTO transactions (transactionId, userId, type, description, amount, status) VALUES (?, ?, ?, ?, ?, ?)')
    .run(txId, user.userId, 'Earning', `CPALead Offer: ${title || 'Offer Wall'} ($${payoutUSD})`, userShare, 'Success');

  // Activity log
  db.prepare('INSERT INTO general_activity (userId, action, deviceIp) VALUES (?, ?, ?)')
    .run(user.userId, `CPALead conversion: ${title || 'Offer'} ($${payoutUSD} = ₦${userShare})`, 'webhook');

  // 20% referral commission on user's share
  let commissionAmount = 0;
  if (user.referredBy) {
    const sponsor = db.prepare('SELECT * FROM users WHERE userId = ?').get(user.referredBy);
    if (sponsor && !sponsor.isBanned) {
      commissionAmount = userShare * 0.2;
      db.prepare('UPDATE users SET walletBalance = walletBalance + ?, totalEarnedLifetime = totalEarnedLifetime + ? WHERE userId = ?')
        .run(commissionAmount, commissionAmount, sponsor.userId);

      const commTxId = generateId();
      db.prepare('INSERT INTO transactions (transactionId, userId, type, description, amount, status) VALUES (?, ?, ?, ?, ?, ?)')
        .run(commTxId, sponsor.userId, 'Commission', `CPALead referral commission from ${user.name.split(' ')[0]}`, commissionAmount, 'Success');

      db.prepare('INSERT INTO referral_activity (sponsorId, referralName, actionType, commissionEarned) VALUES (?, ?, ?, ?)')
        .run(sponsor.userId, user.name.split(' ')[0], 'CPALead Commission', commissionAmount);
    }
  }

  res.send('1');
});

// ============ ADMIN ROUTES ============

// Admin login
app.post('/api/admin/login', (req, res) => {
  const { token } = req.body;
  const config = getConfig();
  if (token !== config.adminToken) {
    return res.status(401).json({ error: 'Invalid admin token' });
  }

  const sessionToken = generateId();
  db.prepare('INSERT INTO admin_sessions (token) VALUES (?)').run(sessionToken);
  res.json({ success: true, token: sessionToken });
});

// Admin dashboard stats
app.get('/api/admin/stats', requireAdmin, (req, res) => {
  const totalUsers = db.prepare('SELECT COUNT(*) as count FROM users WHERE userId != ?').get('admin_master').count;
  const bannedUsers = db.prepare('SELECT COUNT(*) as count FROM users WHERE isBanned = 1').get().count;
  const totalWithdrawals = db.prepare('SELECT COALESCE(SUM(amount), 0) as total FROM withdrawal_logs WHERE status = ?').get('Success').total;
  const pendingWithdrawals = db.prepare('SELECT COUNT(*) as count FROM withdrawal_logs WHERE status = ?').get('Pending').count;
  const pendingAmount = db.prepare('SELECT COALESCE(SUM(amount), 0) as total FROM withdrawal_logs WHERE status = ?').get('Pending').total;
  const totalPayouts = db.prepare('SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE type = ? AND status = ?').get('Earning', 'Success').total;
  const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Africa/Lagos' });
  const todayCheckins = db.prepare('SELECT COUNT(*) as count FROM users WHERE lastCheckInDate = ?').get(today).count;

  res.json({ totalUsers, bannedUsers, totalWithdrawals, pendingWithdrawals, pendingAmount, totalPayouts, todayCheckins });
});

// Admin config
app.get('/api/admin/config', requireAdmin, (req, res) => {
  res.json(getConfig());
});

app.post('/api/admin/config', requireAdmin, (req, res) => {
  const { isMaintenanceMode, isWithdrawalActive, usdToNairaRate } = req.body;

  if (isMaintenanceMode !== undefined) {
    db.prepare('UPDATE global_config SET value = ? WHERE key = ?').run(isMaintenanceMode ? 'true' : 'false', 'isMaintenanceMode');
  }
  if (isWithdrawalActive !== undefined) {
    db.prepare('UPDATE global_config SET value = ? WHERE key = ?').run(isWithdrawalActive ? 'true' : 'false', 'isWithdrawalActive');
  }
  if (usdToNairaRate !== undefined) {
    db.prepare('UPDATE global_config SET value = ? WHERE key = ?').run(String(usdToNairaRate), 'usdToNairaRate');
  }

  res.json({ success: true, config: getConfig() });
});

// Admin: Pending withdrawals
app.get('/api/admin/withdrawals', requireAdmin, (req, res) => {
  const { status } = req.query;
  let query = 'SELECT w.*, u.name as userName, u.whatsappNumber FROM withdrawal_logs w JOIN users u ON w.userId = u.userId';
  if (status) {
    query += ' WHERE w.status = ?';
    const withdrawals = db.prepare(query).all(status);
    return res.json(withdrawals);
  }
  const withdrawals = db.prepare(query + ' ORDER BY w.createdAt DESC').all();
  res.json(withdrawals);
});

// Admin: Approve withdrawal
app.post('/api/admin/withdrawals/:logId/approve', requireAdmin, (req, res) => {
  const { logId } = req.params;
  const withdrawal = db.prepare('SELECT * FROM withdrawal_logs WHERE logId = ?').get(logId);
  if (!withdrawal) return res.status(404).json({ error: 'Withdrawal not found' });

  db.prepare('UPDATE withdrawal_logs SET status = ? WHERE logId = ?').run('Success', logId);
  db.prepare('UPDATE transactions SET status = ? WHERE userId = ? AND type = ? AND amount = ? AND status = ?')
    .run('Success', withdrawal.userId, 'Withdrawal', withdrawal.amount, 'Pending');

  res.json({ success: true });
});

// Admin: Reject withdrawal (refund)
app.post('/api/admin/withdrawals/:logId/reject', requireAdmin, (req, res) => {
  const { logId } = req.params;
  const withdrawal = db.prepare('SELECT * FROM withdrawal_logs WHERE logId = ?').get(logId);
  if (!withdrawal) return res.status(404).json({ error: 'Withdrawal not found' });

  db.prepare('UPDATE withdrawal_logs SET status = ? WHERE logId = ?').run('Failed', logId);
  db.prepare('UPDATE transactions SET status = ? WHERE userId = ? AND type = ? AND amount = ? AND status = ?')
    .run('Failed', withdrawal.userId, 'Withdrawal', withdrawal.amount, 'Pending');

  // Refund to user
  db.prepare('UPDATE users SET walletBalance = walletBalance + ? WHERE userId = ?').run(withdrawal.amount, withdrawal.userId);

  // Log refund transaction
  const txId = generateId();
  db.prepare('INSERT INTO transactions (transactionId, userId, type, description, amount, status) VALUES (?, ?, ?, ?, ?, ?)')
    .run(txId, withdrawal.userId, 'Earning', 'Withdrawal rejected - Refund', withdrawal.amount, 'Success');

  res.json({ success: true });
});

// Admin: All users
app.get('/api/admin/users', requireAdmin, (req, res) => {
  const { search, page = 1 } = req.query;
  const limit = 50;
  const offset = (page - 1) * limit;
  let query = 'SELECT userId, name, whatsappNumber, walletBalance, totalEarnedLifetime, lastCheckInDate, lastLoginIp, isBanned, createdAt FROM users WHERE userId != ?';
  const params = ['admin_master'];

  if (search) {
    query += ' AND (name LIKE ? OR whatsappNumber LIKE ? OR userId LIKE ?)';
    const s = `%${search}%`;
    params.push(s, s, s);
  }

  query += ' ORDER BY createdAt DESC LIMIT ? OFFSET ?';
  params.push(limit, offset);

  const users = db.prepare(query).all(...params);
  res.json(users);
});

// Admin: User detail
app.get('/api/admin/users/:userId', requireAdmin, (req, res) => {
  const user = db.prepare('SELECT userId, name, whatsappNumber, walletBalance, totalEarnedLifetime, lastCheckInDate, lastLoginIp, isBanned, referredBy, createdAt FROM users WHERE userId = ?').get(req.params.userId);
  if (!user) return res.status(404).json({ error: 'User not found' });

  const transactions = db.prepare('SELECT * FROM transactions WHERE userId = ? ORDER BY createdAt DESC LIMIT 50').all(user.userId);
  const activities = db.prepare('SELECT * FROM general_activity WHERE userId = ? ORDER BY createdAt DESC LIMIT 50').all(user.userId);

  res.json({ user, transactions, activities });
});

// Admin: Ban user
app.post('/api/admin/users/:userId/ban', requireAdmin, (req, res) => {
  db.prepare('UPDATE users SET isBanned = 1, walletBalance = 0 WHERE userId = ?').run(req.params.userId);
  res.json({ success: true });
});

// Admin: Unban user
app.post('/api/admin/users/:userId/unban', requireAdmin, (req, res) => {
  db.prepare('UPDATE users SET isBanned = 0 WHERE userId = ?').run(req.params.userId);
  res.json({ success: true });
});

// Admin: Fraud scanner (IPs with > 3 accounts)
app.get('/api/admin/fraud', requireAdmin, (req, res) => {
  const fraudIPs = db.prepare(`
    SELECT lastLoginIp, COUNT(*) as accountCount, GROUP_CONCAT(name, ', ') as users
    FROM users
    WHERE userId != 'admin_master' AND lastLoginIp IS NOT NULL
    GROUP BY lastLoginIp
    HAVING accountCount > 3
    ORDER BY accountCount DESC
  `).all();
  res.json(fraudIPs);
});

// Admin: All activity
app.get('/api/admin/activity', requireAdmin, (req, res) => {
  const { type } = req.query;
  if (type === 'general') {
    const activities = db.prepare('SELECT g.*, u.name as userName FROM general_activity g JOIN users u ON g.userId = u.userId ORDER BY g.createdAt DESC LIMIT 200').all();
    return res.json(activities);
  }
  if (type === 'referral') {
    const activities = db.prepare('SELECT * FROM referral_activity ORDER BY createdAt DESC LIMIT 200').all();
    return res.json(activities);
  }
  res.json([]);
});

// SPA routes
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Fast Earn GPT running on port ${PORT}`);
});
