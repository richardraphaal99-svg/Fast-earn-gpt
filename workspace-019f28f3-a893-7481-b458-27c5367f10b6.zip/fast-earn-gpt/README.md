# 💰 Fast Earn GPT

A fully functional, mobile-optimized Get-Paid-To (GPT) and micro-task web application with both a **Public User Platform** and a **Secure Admin Panel** integrated into a single unified system.

![Node.js](https://img.shields.io/badge/Node.js-Express-green)
![SQLite](https://img.shields.io/badge/Database-SQLite-blue)
![Mobile](https://img.shields.io/badge/Optimized-Mobile-purple)

---

## 🚀 Quick Start

```bash
cd fast-earn-gpt
npm install
npm start
```

Then open:
- **User Platform:** http://localhost:3000
- **Admin Panel:** http://localhost:3000/admin

---

## 🔐 Default Admin Credentials

| Field | Value |
|-------|-------|
| Admin Access Token | `FastAdmin2024!Secure#Token` |

> ⚠️ **Change this immediately** in production via the database or by editing the initialization in `database.js`.

---

## 📱 Features

### Public User Platform (`/`)

| Feature | Description |
|---------|-------------|
| **Registration & Login** | Name, WhatsApp Number, Password, optional Referral Code. Collects device IP. |
| **IP Guardrails** | Max 5 accounts per device network IP. Rate-limited endpoints (30 req/min). |
| **Referral Fraud Protection** | Same-IP referrals are approved but 20% commission is blocked to prevent self-farming. |
| **Dashboard Tabs** | Wallet, Tasks (Offer Wall), Leaderboard (Top 10), Activity Stream |
| **Daily Check-In** | ₦10 per day. Auto-unlocks at midnight (Africa/Lagos timezone). 20% commission to sponsor. |
| **CPALead Offer Wall** | Placeholder iframe container for unlimited CPALead offer wall integration. |
| **Leaderboard** | Top 10 lifetime earners. Names sanitized (e.g., "Promise R."). |
| **Activity Stream** | Live timeline of transactions, account activity, and referral activity. |
| **Pin-Protected Withdrawal** | Min ₦1,000 / Max ₦100,000. Requires 4-digit PIN. Immediate balance deduction. |
| **Maintenance Mode** | Shows maintenance screen when admin toggles it on. |

### Secure Admin Panel (`/admin`)

| Feature | Description |
|---------|-------------|
| **System Toggles** | Maintenance Mode ON/OFF, Withdrawal Gateway ON/OFF |
| **USD→NGN Rate Editor** | Instantly update the conversion rate (default: ₦1,600/$1) |
| **Withdrawal Monitor** | View all pending requests with bank details. Approve or Reject (auto-refund). |
| **Fraud Scanner** | Flags IPs hosting 3+ accounts with user lists. |
| **User Management** | Search, filter, view full data logs, ban/unban users. |
| **Ban Action** | Permanently locks access and sets wallet balance to ₦0. |
| **Real-time Stats** | Total users, daily check-ins, pending withdrawals, total payouts. |
| **Postback URL Display** | Shows the CPALead postback endpoint for easy configuration. |

---

## 🔄 CPALead Postback Integration

Configure your CPALead network to send postbacks to:

```
http://yourdomain.com/api/postback/cpalead?subid={USER_ID}&payout={PAYOUT_USD}&title={OFFER_TITLE}
```

### How it works:
1. CPA network sends webhook with `subid` (user ID), `payout` (USD), and `title`
2. System converts USD → NGN using global rate (e.g., $0.80 × 1600 = ₦1,280)
3. Applies 50/50 split → User gets ₦640
4. 20% commission to sponsor → ₦128 (if referral exists and not fraud-flagged)
5. Returns plain text `'1'` to confirm receipt

---

## 🗄️ Database Models

### Users
| Field | Type | Description |
|-------|------|-------------|
| userId | TEXT (UUID) | Primary key |
| name | TEXT | Full name |
| whatsappNumber | TEXT | Unique phone number |
| password | TEXT | Bcrypt hashed |
| withdrawalPin | TEXT | Bcrypt hashed 4-digit PIN |
| referredBy | TEXT | Sponsor userId |
| walletBalance | REAL | Current balance in Naira |
| totalEarnedLifetime | REAL | Lifetime earnings |
| lastCheckInDate | TEXT | YYYY-MM-DD format |
| lastLoginIp | TEXT | Device IP |
| isBanned | BOOLEAN | Ban status |

### Transactions
| Field | Type | Description |
|-------|------|-------------|
| transactionId | TEXT (UUID) | Primary key |
| userId | TEXT | Foreign key |
| type | TEXT | 'Earning', 'Commission', 'Withdrawal' |
| description | TEXT | Transaction description |
| amount | REAL | Naira amount |
| status | TEXT | 'Pending', 'Success', 'Failed' |
| createdAt | TEXT | Timestamp |

### Withdrawal Logs
| Field | Type | Description |
|-------|------|-------------|
| logId | TEXT (UUID) | Primary key |
| userId | TEXT | Foreign key |
| bankName | TEXT | Bank name |
| accountNumber | TEXT | 10-digit account |
| accountName | TEXT | Full account name |
| amount | REAL | Naira amount |
| status | TEXT | 'Pending', 'Success', 'Failed' |

### Global Configuration
| Key | Default | Description |
|-----|---------|-------------|
| isMaintenanceMode | false | Blocks public access |
| isWithdrawalActive | true | Enables/disables withdrawals |
| usdToNairaRate | 1600 | USD→NGN conversion rate |
| adminToken | FastAdmin2024!Secure#Token | Admin panel access token |

---

## 🛡️ Security Features

- ✅ Bcrypt password hashing (10 rounds)
- ✅ 4-digit withdrawal PIN with separate hash
- ✅ IP-based rate limiting (30 requests/minute)
- ✅ Max 5 accounts per IP address
- ✅ Same-IP referral fraud detection
- ✅ Session token authentication
- ✅ Admin token isolation
- ✅ Input sanitization
- ✅ SQL injection protection (parameterized queries)

---

## 📂 Project Structure

```
fast-earn-gpt/
├── server.js           # Express server + all API routes
├── database.js         # SQLite database setup + models
├── package.json        # Dependencies
├── data.db             # SQLite database (auto-created)
├── public/
│   ├── index.html      # Mobile-optimized user SPA
│   └── admin.html      # Admin panel SPA
└── README.md
```

---

## 🔧 Production Deployment

### Environment Variables
```bash
PORT=3000              # Server port (default: 3000)
```

### Recommended Setup
1. Use a reverse proxy (Nginx/Caddy) with SSL
2. Set up proper environment variables
3. Change the default admin token
4. Configure CPALead postback URL in your CPA network
5. Set up database backups
6. Consider using PM2 for process management: `pm2 start server.js`

---

## 📝 API Endpoints Summary

### Public
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | /api/status | No | Check maintenance status |
| POST | /api/register | No | Create account |
| POST | /api/login | No | Login |
| GET | /api/postback/cpalead | No | CPA network webhook |

### User (requires Bearer token)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/dashboard | Dashboard data |
| POST | /api/checkin | Daily check-in |
| GET | /api/leaderboard | Top 10 earners |
| GET | /api/activity | Activity stream |
| POST | /api/withdraw | Request withdrawal |
| GET | /api/withdrawals | Withdrawal history |

### Admin (requires admin Bearer token)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/admin/login | Admin authentication |
| GET | /api/admin/stats | Dashboard statistics |
| GET/POST | /api/admin/config | Read/update system config |
| GET | /api/admin/withdrawals | List withdrawals |
| POST | /api/admin/withdrawals/:id/approve | Approve withdrawal |
| POST | /api/admin/withdrawals/:id/reject | Reject & refund |
| GET | /api/admin/users | List/search users |
| GET | /api/admin/users/:id | User detail |
| POST | /api/admin/users/:id/ban | Ban user |
| POST | /api/admin/users/:id/unban | Unban user |
| GET | /api/admin/fraud | Fraud scanner |
| GET | /api/admin/activity | Activity logs |

---

## License

MIT License - Free to use and modify.
